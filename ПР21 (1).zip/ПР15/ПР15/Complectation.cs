﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПР15
{
    public partial class Complectation : Form
    {
        public Complectation()
        {
            InitializeComponent();

            var imagePath = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyPictures), "ПР15", "car.jpg");
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void Complectation_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double cena;
            double dop;
            double discount;
            double total;

            cena = 415000;
            dop = 0;

            if (checkBox1.Checked)
            {
                dop += 1200;
            }

            if (checkBox2.Checked)
            {
                dop += 4500;
            }

            if (checkBox3.Checked)
            {
                dop += 12000;
            }

            if (checkBox4.Checked)
            {
                dop += 20000;
            }

            total = cena + dop;

            string st;
            st = "Цена в выбранной комплектации: " + total.ToString("C");
            if(dop != 0)
            {
                st += "\nВ том числе доп. оборудование: " + dop.ToString("C");
            }

            if((checkBox1.Checked) && (checkBox2.Checked) && (checkBox3.Checked) && (checkBox4.Checked))
            {
                discount = total * 0.1;
                total -= discount;
                st += "\nСкидка за доп. оборудование (10%): " + discount.ToString("C") +
                      "\nИтого: " + total.ToString("C");
            }

            label2.Text = st;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "";
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "";
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = "";
        }
    }
}
