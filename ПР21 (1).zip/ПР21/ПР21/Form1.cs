namespace ПР21
{
    public partial class Form1 : Form
    {
        private string fn = string.Empty;

        private bool docChanged = false;

        public Form1()
        {
            InitializeComponent();

            textBox1.ScrollBars = ScrollBars.Vertical;
            textBox1.Text = string.Empty;

            this.Text = "NkEdit - Новый документ";

            toolStrip1.Visible = true;
            панельИнструментовToolStripMenuItem.Checked = true;

            openFileDialog1.DefaultExt = "txt";
            openFileDialog1.Filter = "Текст|*.txt";
            openFileDialog1.Title = "Открыть документ";
            openFileDialog1.Multiselect = false;

            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Filter = "Текст|*.txt";
            saveFileDialog1.Title = "Сохранить документ";
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenDocument();
        }

        private void OpenDocument()
        {
            openFileDialog1.FileName = string.Empty;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fn = openFileDialog1.FileName;
                this.Text = fn;

                try
                {
                    System.IO.StreamReader sr = new System.IO.StreamReader(fn);

                    textBox1.Text = sr.ReadToEnd();
                    textBox1.SelectionStart = textBox1.TextLength;

                    sr.Close();

                    docChanged = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка чтения файла.\n" +
                        ex.ToString(), "MEdit",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private int SaveDocument()
        {
            int result = 0;

            if (fn == string.Empty)
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    fn = saveFileDialog1.FileName;
                    this.Text = fn;
                }
                else result = -1;
            }
            if (fn != string.Empty)
            {
                try
                {
                    System.IO.FileInfo fi = new FileInfo(fn);

                    StreamWriter sw = fi.CreateText();

                    sw.Write(textBox1.Text);

                    sw.Close();
                    result = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка чтения файла.\n" +
                    ex.ToString(), "MEdit",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                }
            }

            return result;
        }

        private void создатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateDocument();
        }

        private void CreateDocument()
        {
            if (docChanged)
            {
                DialogResult dr;
                dr = MessageBox.Show("Сохранить изменения ?", "NkEdit",
                    MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Warning);

                switch (dr)
                {
                    case DialogResult.Yes:
                        if (SaveDocument() == 0)
                        {
                            textBox1.Clear();
                            docChanged = true;
                        }
                        break;
                    case DialogResult.No:
                        textBox1.Clear();
                        docChanged = true;
                        break;
                    case DialogResult.Cancel:
                        break;
                }
            }
            else
            {
                textBox1.Clear();
            }

            fn = string.Empty;
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveDocument();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void панельИнструментовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip1.Visible =! toolStrip1.Visible;
            панельИнструментовToolStripMenuItem.Checked =! панельИнструментовToolStripMenuItem.Checked;
        }

        private void шрифтToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.Font = textBox1.Font;

            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                textBox1.Font = fontDialog1.Font;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            docChanged = true;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (docChanged)
            {
                DialogResult dr;
                dr = MessageBox.Show("Сохранить изменения ?", "NkEdit",
                    MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Warning);

                switch (dr)
                {
                    case DialogResult.Yes:
                        if (SaveDocument() != 0)
                            e.Cancel = true;
                        break;
                    case DialogResult.No:
                        break;
                    case DialogResult.Cancel:
                        e.Cancel = true;
                        break;
                }
            }
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 about = new Form2();
            about.ShowDialog();
        }

        private void печатьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            CreateDocument();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            OpenDocument();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            SaveDocument();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }
    }
}
