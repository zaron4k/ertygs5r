namespace ПР20
{
    public partial class Form1 : Form
    {
        string _imagesDir;

        public Form1()
        {
            InitializeComponent();

            var oneDrivePath = Environment.GetEnvironmentVariable("OneDrive");
            _imagesDir = Path.Combine(oneDrivePath, "Документы", "ТРПО", "ПР19", "Изображения");

            FillListBox();
        }

        private bool FillListBox()
        {
            DirectoryInfo di = new DirectoryInfo(_imagesDir);

            FileInfo[] jpgFi = di.GetFiles("*.jpg");
            FileInfo[] pngFi = di.GetFiles("*.png");
            FileInfo[] jpegFi = di.GetFiles("*.jpeg");

            FileInfo[] fi = jpgFi
                .Union(pngFi)
                .Union(jpegFi)
                .ToArray();

            listBox1.Items.Clear();

            foreach (var fc in fi)
            {
                listBox1.Items.Add(fc.Name);
            }

            if (fi.Length > 0)
            {
                var imagePath = Path.Combine(_imagesDir, listBox1.Items[0].ToString());
                ShowPicture(imagePath);
                return true;
            }

            return false;
        }

        private void ShowPicture(string picturePath)
        {
            pictureBox1.Visible = false;

            pictureBox1.Image = Bitmap.FromFile(picturePath);

            if ((pictureBox1.Image.Width > pictureBox1.Width) ||
                (pictureBox1.Image.Height > pictureBox1.Height))
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            }

            pictureBox1.Visible = true;

            this.Text = picturePath;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fb = new FolderBrowserDialog();

            fb.Description = "Выберите папку, в которой находятся иллюстрации";

            fb.ShowNewFolderButton = false;

            fb.SelectedPath = _imagesDir;

            if (fb.ShowDialog() == DialogResult.OK)
            {
                _imagesDir = fb.SelectedPath;
                
                if (!FillListBox())
                {
                    pictureBox1.Image = null;
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var currentIndex = listBox1.SelectedIndex;
            var imagePath = listBox1.Items[currentIndex].ToString();

            var fullImagePath = Path.Combine(_imagesDir, imagePath);

            ShowPicture(fullImagePath);
        }
    }
}
