﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ПР19
{
    public partial class Form1 : Form
    {
        List<string> imgList = new List<string>();
        int nImg = 0;

        string aPath;

        public Form1()
        {
            InitializeComponent();

            DirectoryInfo di;

            var oneDrivePath = Environment.GetEnvironmentVariable("OneDrive");
            var imagesDir = Path.Combine(oneDrivePath, "Документы", "ТРПО", "ПР19", "Изображения");

            di = new DirectoryInfo(imagesDir);
            aPath = di.FullName;

            FillListBox(aPath);
        }

        private bool FillListBox(string aPath)
        {
            DirectoryInfo di = new DirectoryInfo(aPath);

            FileInfo[] fi = di.GetFiles("*.jpg");

            imgList.Clear();

            foreach(var fc in fi)
            {
                imgList.Add(fc.Name);
            }

            if(fi.Length == 0)
            {
                button2.Enabled = false;
                button3.Enabled = false;
                return false;
            }
            else
            {
                nImg = 0;
                ShowPicture(aPath + "\\" + imgList[nImg]);

                button3.Enabled = false;

                if (imgList.Count == 1)
                {
                    button2.Enabled = false;
                }

                else
                    button2.Enabled = true;

                return true;
            }
        }

        private void ShowPicture(string aPicture)
        {
            pictureBox1.Visible = false;

            pictureBox1.Image = Bitmap.FromFile(aPicture);

            if((pictureBox1.Image.Width > pictureBox1.Width) ||
                (pictureBox1.Image.Height > pictureBox1.Height))
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else
            {
                pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            }

            pictureBox1.Visible = true;

            this.Text = aPicture;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!button2.Enabled)
                button2.Enabled = true;

            if(nImg > 0)
            {
                nImg--;

                ShowPicture(aPath + "\\" + imgList[nImg]);

                if(nImg == 0)
                {
                    button3.Enabled = false;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!button3.Enabled)
                button3.Enabled = true;

            if (nImg < imgList.Count)
            {
                nImg++;

                ShowPicture(aPath + "\\" + imgList[nImg]);

                if (nImg == imgList.Count - 1)
                {
                    button2.Enabled = false;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fb = new FolderBrowserDialog();

            fb.Description = "Выберите папку,\n" + "в которой находятся иллюстрации";

            fb.ShowNewFolderButton = false;

            fb.SelectedPath = aPath;

            if(fb.ShowDialog() == DialogResult.OK)
            {
                aPath = fb.SelectedPath;

                if (!FillListBox(fb.SelectedPath)){
                    pictureBox1.Image = null;
                }
            }
        }
    }
}
